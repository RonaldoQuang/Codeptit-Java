package test;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception{
        ObjectInputStream ois=new ObjectInputStream(new BufferedInputStream(new FileInputStream("DATA.in")));
        ArrayList<Pair> a= (ArrayList<Pair>) ois.readObject();
        Map<Pair,Integer> mp=new HashMap<>();
        ArrayList<Pair> b=new ArrayList<>();
        for(Pair x:a){
            mp.put(x,mp.getOrDefault(x,0)+1);
            if(x.getFirst()<x.getSecond()&&mp.getOrDefault(x,0)==1) b.add(x);
        }
        Collections.sort(b);
        for(Pair x:b){
            System.out.println(x);
        }
    }
}
